from flask import Flask
import threading

app = Flask(__name__)

@app.route('/')
def home():
    return '🤖 Garallah GPT Bot is running 24/7!'

@app.route('/health')
def health():
    return 'OK'

def run_flask():
    app.run(host='0.0.0.0', port=8080)

if __name__ == '__main__':
    run_flask()
