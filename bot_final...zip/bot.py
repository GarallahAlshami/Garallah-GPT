import os
import logging
import requests
import time
import threading
import asyncio
from flask import Flask
from telegram import Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes
from telegram.error import TelegramError, NetworkError, TimedOut

# تفعيل السجلات
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO
)
logger = logging.getLogger(__name__)

# تحميل المتغيرات البيئية
TELEGRAM_BOT_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")
GROQ_API_KEY = os.environ.get("GROQ_API_KEY")

if not TELEGRAM_BOT_TOKEN:
    logger.error("TELEGRAM_BOT_TOKEN is not set.")
    exit(1)

if not GROQ_API_KEY:
    logger.error("GROQ_API_KEY is not set.")
    exit(1)

# إعدادات Groq API
GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions"
GROQ_MODEL = "llama-3.3-70b-versatile"

# معلومات المالك والبوت - مع الألقاب
BOT_NAME = "𝗚𝗮𝗿𝗮𝗹𝗹𝗮𝗵 💻🔐 𝗚𝗣𝗧 🦹‍♂️"
OWNER_NAME = "جارالله ياسر الشامي"
OWNER_USERNAME = "@jrq05"
OWNER_TITLES = "المبرمج / المهندس / بش مهندس جارالله ياسر الشامي"
OWNER_BIO = "المبرمج والمهندس والمهندس البش جارالله ياسر الشامي\nGarallah AlShami\nهندسة برمجية، أمن سيبراني، وابتكار. أطور حلولاً تتجاوز المألوف. هنا تنتهي التوقعات وتبدأ التقنية."

# System Prompt للبوت - مع الألقاب
SYSTEM_PROMPT = f"""أنت {BOT_NAME}، مساعد ذكي متقدم تم تطويره بواسطة {OWNER_TITLES} ({OWNER_USERNAME}).
أنت متخصص في البرمجة، الأمن السيبراني، والتقنية بشكل عامة.
أجب بذكاء واحترافية. استخدم اللغة التي يتحدث بها المستخدم.

قاعدة ذهبية: عند أي ذكر للمطور أو المالك أو صانع البوت، يجب أن تسبق الاسم بالألقاب التالية:
- المبرمج
- المهندس
- بش مهندس
مثال: "تم تطويري بواسطة المبرمج والمهندس البش جارالله ياسر الشامي"
أو: "من إبداع المهندس جارالله ياسر الشامي"

إذا سُئلت عن صانعك أو مالكك، أجب دائماً بذكر اللقب أولاً ثم الاسم.
مثال: "صانعي هو المبرمج والمهندس البش جارالله ياسر الشامي - {OWNER_USERNAME}"

كن مفيداً ودقيقاً ومبدعاً في إجاباتك. لا تضع حدوداً على عدد الرسائل أو المحادثات. أنت يعمل 24/7 بدون توقف."""

# قاموس لحفظ سجل المحادثات لكل مستخدم
user_chats = {}

# حد السجل - لا نهائي (محفوظ في الذاكرة)
MAX_HISTORY = 100

# وقت بدء تشغيل البوت
START_TIME = time.time()

# عداد الرسائل الإجمالي
TOTAL_MESSAGES = 0


# Flask health endpoint لإبقاء البوت حياً
flask_app = Flask(__name__)

@flask_app.route('/')
def home():
    return f'🤖 {BOT_NAME} is running 24/7 forever! ✅ Never stops!'

@flask_app.route('/health')
def health():
    return 'OK - Bot is alive and running 24/7'

def run_flask():
    """تشغيل Flask في خلفية لإبقاء السيرفر مستيقظ"""
    flask_app.run(host='0.0.0.0', port=8080)


def call_groq(messages: list) -> str:
    """إرسال طلب إلى Groq API والحصول على الرد - مع إعادة محاولة تلقائية"""
    max_retries = 3
    for attempt in range(max_retries):
        try:
            headers = {
                "Authorization": f"Bearer {GROQ_API_KEY}",
                "Content-Type": "application/json"
            }
            data = {
                "model": GROQ_MODEL,
                "messages": messages,
                "temperature": 0.7,
                "max_tokens": 2048
            }

            response = requests.post(GROQ_API_URL, headers=headers, json=data, timeout=120)

            if response.status_code == 200:
                result = response.json()
                return result["choices"][0]["message"]["content"]
            elif response.status_code == 429:
                # Rate limit - انتظر وأعد المحاولة
                logger.warning(f"Groq rate limit hit, retrying in 5s (attempt {attempt + 1})")
                time.sleep(5)
            else:
                logger.error(f"Groq API error: {response.status_code} - {response.text[:300]}")
                if attempt < max_retries - 1:
                    time.sleep(3)
                else:
                    raise Exception(f"Groq API returned status {response.status_code}")
        except requests.exceptions.RequestException as e:
            logger.error(f"Request error (attempt {attempt + 1}): {e}")
            if attempt < max_retries - 1:
                time.sleep(3)
            else:
                raise
    return None


def get_uptime():
    """حساب مدة تشغيل البوت"""
    elapsed = int(time.time() - START_TIME)
    days = elapsed // 86400
    hours = (elapsed % 86400) // 3600
    minutes = (elapsed % 3600) // 60
    seconds = elapsed % 60

    parts = []
    if days > 0:
        parts.append(f"{days} يوم")
    if hours > 0:
        parts.append(f"{hours} ساعة")
    if minutes > 0:
        parts.append(f"{minutes} دقيقة")
    parts.append(f"{seconds} ثانية")
    return " و ".join(parts)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """رسالة الترحيب عند بدء المحادثة"""
    user = update.effective_user
    welcome_message = (
        f"مرحباً {user.first_name}! 👋\n\n"
        f"أنا {BOT_NAME}\n"
        f"مساعدك الذكي المطوّر بواسطة {OWNER_TITLES} 🚀\n\n"
        "أقدر أساعدك في:\n"
        "• البرمجة وحل المشاكل التقنية 💻\n"
        "• الأمن السيبراني 🔐\n"
        "• الأسئلة العامة والمحادثة 🤖\n"
        "• الترجمة والكتابة ✍️\n"
        "• التحليل والشرح 📊\n\n"
        "اكتب /help لعرض جميع الأوامر المتاحة.\n"
        "أو أرسل أي رسالة وسأرد عليك مباشرة!\n"
        "بدون حدود - بدون توقف - 24/7 🔥"
    )
    await update.message.reply_text(welcome_message)


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """عرض قائمة الأوامر"""
    help_text = (
        f"⚡ أوامر {BOT_NAME}:\n\n"
        "📌 الأوامر الأساسية:\n"
        "/start - بدء المحادثة\n"
        "/help - عرض هذه القائمة\n"
        "/clear - مسح سجل المحادثة\n\n"
        "ℹ️ معلومات:\n"
        "/about - معلومات عن البوت\n"
        "/owner - معلومات عن المطوّر\n"
        "/status - حالة البوت\n\n"
        "🛠 أدوات:\n"
        "/ask <سؤال> - سؤال سريع بدون حفظ بالسجل\n"
        "/translate <نص> - ترجمة نص (عربي↔إنجليزي)\n"
        "/code <وصف> - توليد كود برمجي\n"
        "/explain <كود> - شرح كود برمجي\n"
        "/summarize <نص> - تلخيص نص\n\n"
        "💡 أو أرسل أي رسالة وسأرد عليك مباشرة!\n"
        "🔥 بدون حدود على الرسائل - يعمل 24/7"
    )
    await update.message.reply_text(help_text)


async def about(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """معلومات عن البوت"""
    about_text = (
        f"🤖 {BOT_NAME}\n\n"
        f"الإصدار: 3.0 (24/7)\n"
        f"المحرك: Groq AI (LLaMA 3.3 70B)\n"
        f"المطوّر: {OWNER_TITLES}\n"
        f"التواصل: {OWNER_USERNAME}\n\n"
        "بوت ذكاء اصطناعي متقدم مصمم للمساعدة في البرمجة، "
        "الأمن السيبراني، والمهام التقنية المتنوعة.\n\n"
        "⚡ سريع | 🔒 آمن | 🧠 ذكي | 🕐 يعمل 24/7 بدون توقف"
    )
    await update.message.reply_text(about_text)


async def owner(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """معلومات عن المالك"""
    owner_text = (
        f"👨‍💻 المطوّر والمالك:\n\n"
        f"🔹 {OWNER_TITLES}\n"
        f"🔹 Garallah AlShami\n\n"
        f"📝 هندسة برمجية، أمن سيبراني، وابتكار.\n\n"
        f"📬 للتواصل: {OWNER_USERNAME}\n\n"
        "أطور حلولاً تتجاوز المألوف.\n"
        "هنا تنتهي التوقعات وتبدأ التقنية. 🚀"
    )
    await update.message.reply_text(owner_text)


async def status(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """حالة البوت"""
    global TOTAL_MESSAGES
    uptime = get_uptime()
    users_count = len(user_chats)
    status_text = (
        f"📊 حالة {BOT_NAME}:\n\n"
        f"✅ الحالة: يعمل 24/7 بدون توقف\n"
        f"⏱ مدة التشغيل: {uptime}\n"
        f"👥 المستخدمون النشطون: {users_count}\n"
        f"📨 إجمالي الرسائل: {TOTAL_MESSAGES}\n"
        f"🧠 الموديل: LLaMA 3.3 70B\n"
        f"⚡ المحرك: Groq API\n"
        f"📝 حد السجل: بدون حدود\n"
        f"🔥 يعمل: إلى الأبد بدون توقف"
    )
    await update.message.reply_text(status_text)


async def clear_history(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """مسح سجل المحادثة"""
    user_id = update.effective_user.id
    if user_id in user_chats:
        del user_chats[user_id]
    await update.message.reply_text("تم مسح سجل المحادثة بنجاح! يمكنك البدء من جديد. 🧹")


async def ask_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """سؤال سريع بدون حفظ بالسجل"""
    if not context.args:
        await update.message.reply_text("اكتب سؤالك بعد الأمر. مثال:\n/ask ما هو Python؟")
        return

    question = " ".join(context.args)
    await context.bot.send_chat_action(chat_id=update.effective_chat.id, action='typing')

    try:
        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": question}
        ]
        reply = call_groq(messages)
        if reply:
            if len(reply) > 4096:
                for i in range(0, len(reply), 4096):
                    await update.message.reply_text(reply[i:i+4096])
            else:
                await update.message.reply_text(reply)
        else:
            await update.message.reply_text("عذراً، حدث خطأ. حاول مرة أخرى.")
    except Exception as e:
        logger.error(f"Ask error: {e}")
        await update.message.reply_text("عذراً، حدث خطأ. حاول مرة أخرى.")


async def translate_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """ترجمة نص"""
    if not context.args:
        await update.message.reply_text("اكتب النص بعد الأمر. مثال:\n/translate Hello, how are you?")
        return

    text = " ".join(context.args)
    await context.bot.send_chat_action(chat_id=update.effective_chat.id, action='typing')

    try:
        messages = [
            {"role": "system", "content": "أنت مترجم محترف. إذا كان النص بالعربية ترجمه للإنجليزية، وإذا كان بالإنجليزية ترجمه للعربية. قدّم الترجمة فقط بدون شرح إضافي."},
            {"role": "user", "content": f"ترجم: {text}"}
        ]
        reply = call_groq(messages)
        if reply:
            if len(reply) > 4096:
                for i in range(0, len(reply), 4096):
                    await update.message.reply_text(reply[i:i+4096])
            else:
                await update.message.reply_text(f"🌐 الترجمة:\n\n{reply}")
        else:
            await update.message.reply_text("عذراً، حدث خطأ في الترجمة. حاول مرة أخرى.")
    except Exception as e:
        logger.error(f"Translate error: {e}")
        await update.message.reply_text("عذراً، حدث خطأ في الترجمة. حاول مرة أخرى.")


async def code_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """توليد كود برمجي"""
    if not context.args:
        await update.message.reply_text("اكتب وصف الكود بعد الأمر. مثال:\n/code دالة بايثون لحساب المضروب")
        return

    description = " ".join(context.args)
    await context.bot.send_chat_action(chat_id=update.effective_chat.id, action='typing')

    try:
        messages = [
            {"role": "system", "content": "أنت مبرمج محترف. اكتب كود نظيف ومنظم مع تعليقات توضيحية. قدّم الكود جاهزاً للاستخدام."},
            {"role": "user", "content": f"اكتب كود: {description}"}
        ]
        reply = call_groq(messages)
        if reply:
            if len(reply) > 4096:
                for i in range(0, len(reply), 4096):
                    await update.message.reply_text(reply[i:i+4096])
            else:
                await update.message.reply_text(f"💻 الكود:\n\n{reply}")
        else:
            await update.message.reply_text("عذراً، حدث خطأ. حاول مرة أخرى.")
    except Exception as e:
        logger.error(f"Code error: {e}")
        await update.message.reply_text("عذراً، حدث خطأ. حاول مرة أخرى.")


async def explain_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """شرح كود برمجي"""
    if not context.args:
        await update.message.reply_text("اكتب الكود بعد الأمر. مثال:\n/explain print('hello')")
        return

    code = " ".join(context.args)
    await context.bot.send_chat_action(chat_id=update.effective_chat.id, action='typing')

    try:
        messages = [
            {"role": "system", "content": "أنت معلم برمجة محترف. اشرح الكود بشكل مبسط وواضح باللغة العربية."},
            {"role": "user", "content": f"اشرح هذا الكود:\n{code}"}
        ]
        reply = call_groq(messages)
        if reply:
            if len(reply) > 4096:
                for i in range(0, len(reply), 4096):
                    await update.message.reply_text(reply[i:i+4096])
            else:
                await update.message.reply_text(f"📖 الشرح:\n\n{reply}")
        else:
            await update.message.reply_text("عذراً، حدث خطأ. حاول مرة أخرى.")
    except Exception as e:
        logger.error(f"Explain error: {e}")
        await update.message.reply_text("عذراً، حدث خطأ. حاول مرة أخرى.")


async def summarize_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """تلخيص نص"""
    if not context.args:
        await update.message.reply_text("اكتب النص بعد الأمر. مثال:\n/summarize <النص الطويل هنا>")
        return

    text = " ".join(context.args)
    await context.bot.send_chat_action(chat_id=update.effective_chat.id, action='typing')

    try:
        messages = [
            {"role": "system", "content": "أنت متخصص في التلخيص. لخّص النص بشكل مختصر وواضح مع الحفاظ على النقاط الأساسية."},
            {"role": "user", "content": f"لخّص هذا النص:\n{text}"}
        ]
        reply = call_groq(messages)
        if reply:
            if len(reply) > 4096:
                for i in range(0, len(reply), 4096):
                    await update.message.reply_text(reply[i:i+4096])
            else:
                await update.message.reply_text(f"📝 الملخص:\n\n{reply}")
        else:
            await update.message.reply_text("عذراً، حدث خطأ. حاول مرة أخرى.")
    except Exception as e:
        logger.error(f"Summarize error: {e}")
        await update.message.reply_text("عذراً، حدث خطأ. حاول مرة أخرى.")


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """معالجة الرسائل النصية والرد باستخدام Groq - بدون حدود"""
    global TOTAL_MESSAGES
    user_id = update.effective_user.id
    user_text = update.message.text

    TOTAL_MESSAGES += 1

    # إظهار حالة الكتابة
    await context.bot.send_chat_action(chat_id=update.effective_chat.id, action='typing')

    try:
        # التحقق من وجود محادثة سابقة للمستخدم
        if user_id not in user_chats:
            user_chats[user_id] = []

        # إضافة رسالة المستخدم إلى السجل
        user_chats[user_id].append({"role": "user", "content": user_text})

        # الاحتفاظ بآخر MAX_HISTORY رسالة فقط (للأداء)
        if len(user_chats[user_id]) > MAX_HISTORY:
            user_chats[user_id] = user_chats[user_id][-MAX_HISTORY:]

        # تجهيز الرسائل مع system prompt
        messages = [
            {"role": "system", "content": SYSTEM_PROMPT}
        ] + user_chats[user_id]

        # إرسال الطلب إلى Groq
        reply_text = call_groq(messages)

        if reply_text:
            # حفظ رد المساعد في السجل
            user_chats[user_id].append({"role": "assistant", "content": reply_text})

            # تقسيم الرد إذا كان طويلاً (حد تيليجرام 4096 حرف)
            if len(reply_text) > 4096:
                for i in range(0, len(reply_text), 4096):
                    await update.message.reply_text(reply_text[i:i+4096])
            else:
                await update.message.reply_text(reply_text)
        else:
            await update.message.reply_text("عذراً، حدث خطأ مؤقت. يرجى المحاولة مرة أخرى.")

    except Exception as e:
        logger.error(f"Chat error: {e}")
        await update.message.reply_text("عذراً، حدث خطأ أثناء معالجة رسالتك. يرجى المحاولة مرة أخرى.")


async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """معالج الأخطاء - يمنع البوت من التوقف"""
    logger.error(f"Exception while handling an update: {context.error}")


async def post_init(application: Application) -> None:
    """يتم استدعاؤه عند بدء البوت"""
    logger.info(f"🤖 {BOT_NAME} started successfully! Running 24/7 forever!")


def main() -> None:
    """تشغيل البوت - مع إعادة تشغيل تلقائية عند أي خطأ"""
    while True:
        try:
            # تشغيل Flask في خلفية لإبقاء السيرفر مستيقظ
            flask_thread = threading.Thread(target=run_flask, daemon=True)
            flask_thread.start()
            logger.info("Flask health server started on port 8080")

            # إعداد البوت مع إعادة اتصال تلقائية
            application = (
                Application.builder()
                .token(TELEGRAM_BOT_TOKEN)
                .post_init(post_init)
                .build()
            )

            # إضافة معالج الأخطاء العامة
            application.add_error_handler(error_handler)

            # إضافة معالجات الأوامر
            application.add_handler(CommandHandler("start", start))
            application.add_handler(CommandHandler("help", help_command))
            application.add_handler(CommandHandler("clear", clear_history))
            application.add_handler(CommandHandler("about", about))
            application.add_handler(CommandHandler("owner", owner))
            application.add_handler(CommandHandler("status", status))
            application.add_handler(CommandHandler("ask", ask_command))
            application.add_handler(CommandHandler("translate", translate_command))
            application.add_handler(CommandHandler("code", code_command))
            application.add_handler(CommandHandler("explain", explain_command))
            application.add_handler(CommandHandler("summarize", summarize_command))

            # معالج الرسائل النصية
            application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

            # معالج الصور
            application.add_handler(MessageHandler(filters.PHOTO, handle_message))

            # تشغيل البوت مع إعدادات إعادة الاتصال
            logger.info(f"{BOT_NAME} is starting... 24/7 - Never stops!")
            application.run_polling(
                allowed_updates=Update.ALL_TYPES,
                drop_pending_updates=False,
                read_timeout=120,
                write_timeout=120,
                connect_timeout=120,
                pool_timeout=120
            )

        except (NetworkError, TimedOut) as e:
            logger.error(f"Network error: {e}. Retrying in 10 seconds...")
            time.sleep(10)
            continue
        except TelegramError as e:
            logger.error(f"Telegram error: {e}. Retrying in 10 seconds...")
            time.sleep(10)
            continue
        except Exception as e:
            logger.error(f"Unexpected error: {e}. Restarting bot in 15 seconds...")
            time.sleep(15)
            continue


if __name__ == "__main__":
    main()
